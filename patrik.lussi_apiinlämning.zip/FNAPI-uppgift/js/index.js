
function printGoals(goals) {
    const goalHolder = document.querySelector("#goal-container");
    goalHolder.innerHTML = "";

    for (let goal of goals) {
        const goalElement = document.createElement("h1");
        goalElement.classList.add("goalTitle");
        const antoherElement = document.createElement("h4");
        let sectionElem = document.createElement("section");
        sectionElem.classList.add("sectionStyling");
        sectionElem.innerHTML="Click here for more info";
        antoherElement.innerHTML = goal.description;
        goalElement.innerHTML = goal.code + "." +" " + goal.title;
        const articleHolder = document.createElement("article");
        articleHolder.append(goalElement,antoherElement,sectionElem);
        goalHolder.append(articleHolder);
        console.log(sectionElem.innerHTML);

        sectionElem.addEventListener("click", function(){
            if (sectionElem.innerHTML == "Click here for more info") {
                getSubGoals(goal.code,sectionElem);
            } else {
                console.log("Fuck off");
                sectionElem.innerHTML = "Click here for more info";
            }
            
        });
    }
}
async function getSubGoals (code,sectionElem) {
    console.log(code);
    const url = `https://unstats.un.org/SDGAPI/v1/sdg/Goal/${code}/Target/List?includechildren=true`
    const response = await fetch(url);
    const data = await response.json();
    printSubGoals(data,sectionElem);

}

function printSubGoals (subGoals,sectionElem) {
   for (let target of subGoals) {
       let subGoalTargets = target.targets;
       printTargets(subGoalTargets,sectionElem);
   }
    
        
}

function printTargets(subGoalTargets,sectionElem) {
    console.log(sectionElem);
    console.log(subGoalTargets);
    sectionElem.innerHTML = "Click here to close";
    for (let target of subGoalTargets) {
        let temp = document.createElement("p");
        temp.classList.add("pstyling")
        temp.innerHTML = temp.innerHTML =target.code+" " + target.title ;
       sectionElem.append(temp);
    }
}

async function getUnGoals() {
    const url = "https://unstats.un.org/SDGAPI/v1/sdg/Goal/List?includechildren=false";
    const response = await fetch(url);
    const data = await response.json();
    printGoals(data);
}


getUnGoals();
